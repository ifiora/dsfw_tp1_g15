import './App.css'

export default function App() {
  return (
    <main>
    <h1>Base TP 1</h1>
    </main>
  )
}
